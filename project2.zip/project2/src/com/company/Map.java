package com.company;

public interface Map<K, V> {

    //insert value into map
    void put(K key , V value);

    //retrive value from map using key
    V get(K key);

    // returns number of data in a map
    int size();

    //check to see if the map is empty
    boolean isEmpty(K key);
}

