package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        hashMap<String,Integer> map = new hashMap<String,Integer>();
        map.put("icon",3);
        map.put("rodd",5);
        map.put("petter",30);
        map.put("giver",100);
        System.out.println(map.get("giver"));
        map.displayEntries();
        System.out.println(map.get("giver"));
    }


}
