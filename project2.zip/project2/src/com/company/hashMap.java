package com.company;

public class hashMap<K, V> implements Map<K,V>{

    private MapEntry<K,V> [] table;
    private static final int   DEFAULT_CAPACITY = 5;
    private static final double LOAD_FACTOR = 0.75;
    private int numberOfArrayEntries = 0;
    private int totalNumberOfEntries ;
    private int sizeOfArray = DEFAULT_CAPACITY;
    private double currentLoadFactor = 0;


    public hashMap(){
        table = new MapEntry[DEFAULT_CAPACITY];
    }

    public hashMap(int capacity){
        table = new MapEntry[capacity];
        sizeOfArray = table.length;
    }

    public int hash(K key ){
        return Math.abs(key.hashCode())% table.length;
    }

    @Override
    public void put(K key, V value) {
        if(calculateLoadFactor()){
            resizeTable();
        }
        if(key == null) return;
        int bucket =  hash(key);
        MapEntry<K,V> current = table[bucket];
        if(table[bucket] == null){
            table[bucket] = new MapEntry<>(key,value,null);
            System.out.println("bucket " + bucket);
            numberOfArrayEntries++;
            totalNumberOfEntries++;
        } else{
            while (current.getNext() != null){
                if(current.getKey().equals(key)){
                    current.setValue(value);
                    break;
                }
                current = current.getNext();
            }
            current.setNext(new MapEntry<K, V>(key, value,null));
            totalNumberOfEntries++;
        }

    }

    private void resizeTable(){
        int oldArraySize = sizeOfArray;
        int nextPrime = oldArraySize * 2;
        int newPrime = getNextPrime(nextPrime);

        MapEntry<K,V> []temp = table;
           table = new MapEntry[newPrime];
           reHash(temp);
           sizeOfArray = table.length;
    }

    public void reHash(MapEntry<K,V> [] array){
        totalNumberOfEntries = 0;
        MapEntry<K,V> oldEntry;
        for(int i = 0; i < array.length;  i++){
            if(array[i] != null){
                while (array[i] != null) {
                    put(array[i].getKey(),array[i].getValue());
                    array[i] = array[i].next;
                }
            }
        }


    }

    private boolean calculateLoadFactor(){
        currentLoadFactor = (double) numberOfArrayEntries/sizeOfArray;
        if(currentLoadFactor >= LOAD_FACTOR){
            return true;
        }else return false;
    }

    @Override
    public V get(K key) {
        int hashedKey = hash(key);
        MapEntry<K,V> current = table[hashedKey];
        while(current != null){
            if(current.getKey().equals(key)){
                return current.getValue();
            } else{
                current = current.getNext();
            }
        }
        return null;
    }

    public void removeEntry(K Key){
        int hashedKey = hash(Key);
        MapEntry<K,V> current = table[hashedKey];
        MapEntry<K,V> previous = null;
        if(table[hashedKey] == null){
            return ;
        }
        if(current.getKey().equals(hashedKey)){
            table[hashedKey] = table[hashedKey].getNext();
            numberOfArrayEntries--;
            totalNumberOfEntries--;
            return;
        } else{
            while(current != null){
                if(current.getKey().equals(Key)){
                    if(previous==null){
                        table[hashedKey]=table[hashedKey].next;
                        totalNumberOfEntries--;
                        return;
                    }
                    else{
                        previous.next = current.getNext();
                        totalNumberOfEntries--;
                        return;
                    }
                }
                previous = current;
                current = current.getNext();
            }
            return;
        }

    }

    @Override
    public int size() {
        return totalNumberOfEntries;
    }

    @Override
    public boolean isEmpty(K key) {
        int hashedKey = hash(key);
        if(table[hashedKey] == null){
            return true;
        }
        else return false;
    }

    public int getNextPrime(int oldPrime){
        int nextPrime = oldPrime;
        if(nextPrime % 2 == 0)
            nextPrime += 1;
        while(!isPrime(nextPrime)){
            nextPrime += 2;
        }
        return nextPrime;
    }

    public boolean isPrime(int checkPrime){
        for(int i=2;2*i<checkPrime;i++) {
            if(checkPrime % i == 0)
                return false;
        }
        return true;
    }

    public void displayEntries(){
        for(int i = 0; i < sizeOfArray; i++) {
            if (table[i] != null) {
                while (table[i] != null) {
                    System.out.println("Key " + table[i].getKey() + " |" + " Value " + table[i].getValue());
                    table[i] = table[i].next;
                }
            }
        }
    }
}
