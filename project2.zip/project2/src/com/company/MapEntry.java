package com.company;

public class MapEntry<K,V> {
    public final K key;
    private V value;
    public MapEntry<K,V> next;


    public MapEntry(K key, V value, MapEntry<K,V> next){
        this.key = key;
        this.value = value;
        this.next = next;
    }

    public V getValue(){
        return value;
    }

    public K getKey() {
        return key;
    }

    public void setValue(V value) {
        this.value = value;
    }

    public void setNext(MapEntry<K,V> next){
        this.next = next;
    }

    public MapEntry<K, V> getNext() {
        return next;
    }
}
